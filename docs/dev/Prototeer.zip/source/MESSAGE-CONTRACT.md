# Development message contract (version 1)

The submitted build is frozen at ../prototype (Git commit f90adea). Development is isolated on branch development and published only at /Prototeer/dev/. The existing /Prototeer/ entry and ZIP must not be overwritten.

## Editable definitions

A director rule has a fields array. Each entry has a user-selected name, type, and value source. Supported types: number, text, boolean, zone, position. Names start with a letter and contain letters, numbers, underscores or hyphens; constructor/prototype/__proto__ are reserved. Maximum 20 unique fields. A new rule starts with no fields.

Sources: constants for all types; observed stat or signal value for numbers; observed tag membership for booleans; observed or linked zone for zone references; observed or signal-origin position for position fields. Position fields are deliberate, explicit choices. There is no player, enemy, pursuit, sound, attack, or mission-specific field type.

A receiver reads a field by its name and required type. Conditions can test message/field existence or compare numbers, text or booleans. Utility scoring can use a named number field. Choose point can read a zone reference or a position field into a named memory slot; the separate Move to stored point action uses that slot. Changing a field name requires updating its readers. Text never automatically executes a command.

## Delivered payload

    { id, name, created, expires, fields: {
        userFieldName: { type, value }
    }}

Only these envelope keys are accepted. There is no automatic source ID, source position, source-tool reference, director/rule reference, priority or stat attachment. A deliberately sent position belongs inside the user-defined fields. Captured input copies in stored destinations follow the same schema. Validation rejects extra hidden envelope properties.

The example sends task (text) and area (zone). The receiving graph uses a constant branch score and chooses a point inside the area. Signal strength is not delivered. Chosen destination coordinates belong to the receiver and are distinct from the source position.

## Transport and diagnostics

World-level messageRoutes records hold lifecycle/deduplication references. World-level messageDebug records hold source coordinates for the debug overlay. Neither is attached to the delivered message or its captured copies. TTL, disabling a director/rule and recipient assignments are enforced by the transport. Acknowledgement removes the exact delivered input, leaving later inputs intact.

DebugSnapshot reads diagnostic records separately. Clearing diagnostic records must not change decisions. Debug data is part of a complete editor save for replay/inspection; it is not part of the receiver input contract. Retention limits are 16,000 route records and 2,000 diagnostic records, with expired records pruned.

This is a data/logic boundary for the supported node system, not a security sandbox for arbitrary third-party JavaScript. A game programmer has access to their own world state. A future engine adapter must pass the delivered payload to receiver logic and must not merge diagnostic data into it. No Unity or Unreal adapter is implemented here.

## Migration and portability

NormalizeWorld upgrades old fixed message definitions to explicit fields. It moves old x/y/source metadata out of inboxes, accepted legacy inputs and stored point message copies without mutating the original imported object. Compatibility readers use the conventional priority/value/zone field names for old graphs.

Projects record messageSchema: 1. Definitions and payloads are ordinary versioned JSON; composition and field readers live in engine.js, independently of DOM, storage and rendering. Engine adapters must preserve types, missing-field behavior, lifetime/acknowledgement semantics, reference resolution and the explicit data boundary. A zone reader resolves the selected area geometry, not the hidden object bindings used to position that area. The present navigation adapter still uses the existing 2D grid; this does not claim arbitrary 3D navigation support.

## Test coverage

The tests cover independent field types/readers, explicit positions, mission-only absence of source data, UI editing, full reconstruction of the demo through editor controls, old-save migration, debug independence, persistence and replay. No Convex, eye tracking or analytics has been added.
