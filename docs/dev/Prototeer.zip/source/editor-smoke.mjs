import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import * as engine from './public/engine.js';
import * as unityExport from './public/unity-export.js';
export function createTestLocalStorage(){
  const storage={};
  return Object.defineProperties(storage,{
    getItem:{value:key=>Object.hasOwn(storage,key)?storage[key]:null},
    setItem:{value:(key,value)=>{storage[key]=String(value);}},
  });
}
export function bootEditor(options={}){const ids=new Map(),all=[];let interval;const decode=s=>String(s??'').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
class Element{constructor(tag='div',attrs=''){this.tagName=tag.toUpperCase();this.attrs=attrs;this.dataset={};for(const m of attrs.matchAll(/data-([\w-]+)="([^"]*)"/g))this.dataset[m[1].replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=decode(m[2]);this.id=attrs.match(/\bid="([^"]*)"/)?.[1]??'';this.value=decode(attrs.match(/\bvalue="([^"]*)"/)?.[1]??'');this.checked=/\bchecked\b/.test(attrs);this.disabled=false;this.style={};this.open=false;this.textContent='';this.children=[];this.classes=new Set((attrs.match(/\bclass="([^"]*)"/)?.[1]??'').split(/\s+/));this.classList={add:c=>this.classes.add(c),remove:c=>this.classes.delete(c),contains:c=>this.classes.has(c),toggle:(c,flag)=>{const on=flag??!this.classes.has(c);if(on)this.classes.add(c);else this.classes.delete(c);return on;}};}set value(value){const v=String(value??'');this._value=this.tagName==='SELECT'&&this.html!==undefined&&![...this.html.matchAll(/<option\b[^>]*\bvalue="([^"]*)"/g)].some(m=>decode(m[1])===v)?'':v;}get value(){return this._value??'';}set innerHTML(html){this.html=html;this.children=parse(html);if(this.tagName==='SELECT'){const opts=[...html.matchAll(/<option\b((?:"[^"]*"|'[^']*'|[^'">])*)>([\s\S]*?)<\/option>/g)],selected=opts.find(m=>/\bselected\b/.test(m[1]))??opts[0];this.value=selected?decode(selected[1].match(/\bvalue="([^"]*)"/)?.[1]??selected[2]):'';}}get innerHTML(){return this.html??'';}querySelectorAll(selector){return this.children.filter(el=>match(el,selector));}querySelector(selector){return this.querySelectorAll(selector)[0]??null;}addEventListener(name,fn){this['on'+name]=fn;}getBoundingClientRect(){return {width:800,height:510,left:0,top:0};}getContext(){return new Proxy({measureText:text=>({width:String(text).length*6})},{get:(obj,key)=>key in obj?obj[key]:()=>{}});}scrollTo(options){this.scrollLeft=options.left??this.scrollLeft??0;this.scrollTop=options.top??this.scrollTop??0;}setPointerCapture(){}showModal(){this.open=true;}close(){this.open=false;}click(){if(!this.disabled)this.onclick?.({target:this,preventDefault(){},stopPropagation(){}});}closest(selector){return match(this,selector)?this:null;}insertAdjacentHTML(_,html){this.innerHTML=html+this.innerHTML;}}
function match(el,selector){if(selector.startsWith('.'))return el.classes.has(selector.slice(1));const attr=selector.match(/^\[([^=\]]+)(?:="([^"]*)")?\](:checked)?$/);if(attr){const name=attr[1],value=el.attrs.match(new RegExp('(?:^|\\s)'+name+'="([^"]*)"'))?.[1];return value!==undefined&&(attr[2]===undefined||value===attr[2])&&(!attr[3]||el.checked);}return el.tagName.toLowerCase()===selector;}
function parse(html){const nodes=[];for(const m of html.matchAll(/<([a-z][\w-]*)\b([^>]*)>/gi)){const el=new Element(m[1],m[2]);if(el.id)ids.set(el.id,el);all.push(el);nodes.push(el);}for(const m of html.matchAll(/<(select|textarea)\b([^>]*\bid="([^"]*)"[^>]*)>([\s\S]*?)<\/\1>/gi)){const el=ids.get(m[3]);if(el){if(m[1].toLowerCase()==='select')el.innerHTML=m[4];else el.value=decode(m[4]);}}return nodes;}
const html=options.html??readFileSync(new URL('./public/index.html',import.meta.url),'utf8');
parse(html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,''));
for(const element of all)element.hidden=/(^|\s)hidden(?:\s|=|$)/.test(element.attrs);
const document={
  getElementById:id=>ids.get(id)??null,
  querySelectorAll:selector=>all.filter(el=>match(el,selector)),
  createElement:tag=>new Element(tag),
  body:all.find(el=>el.tagName==='BODY'),
  activeElement:null,
};
Element.prototype.append=function(...children){this.children.push(...children);};
Element.prototype.replaceChildren=function(...children){this.children=children;this.html='';};
Element.prototype.focus=function(){document.activeElement=this;};
Element.prototype.reportValidity=function(){return !/\brequired\b/.test(this.attrs)||Boolean(this.value);};
Element.prototype.setAttribute=function(name,value){(this.attributeOverrides??={})[name]=String(value);};
Object.defineProperty(Element.prototype,'childElementCount',{get(){return this.children.length;}});
const location=new URL(options.globals?.location?.href??'file:///index.html');
const context={
  __engine:engine,__unityExport:unityExport,atob:globalThis.atob,document,
  window:{devicePixelRatio:1,addEventListener(){}},
  ResizeObserver:class{observe(){}},Image:class{},
  setInterval:fn=>{interval=fn;return 1;},setTimeout:()=>1,clearTimeout(){},clearInterval(){},
  requestAnimationFrame:fn=>fn(),structuredClone,crypto:globalThis.crypto,
  TextEncoder,Blob,URL,URLSearchParams,console,localStorage:createTestLocalStorage(),
  history:{replaceState(_state,_unused,next){location.href=String(next);}},
  fetch:async()=>{throw Error('Unexpected network request in editor smoke test');},
};
Object.assign(context,options.globals??{},{location});
context.globalThis=context;
vm.createContext(context);
if(options.loadProjectHome)vm.runInContext(readFileSync(new URL('./public/project-home.js',import.meta.url),'utf8'),context,{filename:'public/project-home.js'});
let source=options.source??readFileSync(new URL('./public/app.js',import.meta.url),'utf8').replace(/^import\s*\{([^}]+)\}\s*from\s*'\.\/engine\.js';/,'const {$1}=__engine;').replace(/^import\s*\{([^}]+)\}\s*from\s*'\.\/unity-export\.js';/m,'const {$1}=__unityExport;');
const expose='\nglobalThis.editor={world:()=>world,running:()=>running,goGuide,editZone,editBrainNode,setMode,adopt,transform:()=>transform};';
source=options.source?source.replace(/\}\)\(\);\s*$/,expose+'\n})();'):source+expose;
vm.runInContext(source,context,{filename:'public/app.js'});
return {editor:context.editor,get:id=>document.getElementById(id),query:selector=>document.querySelectorAll(selector),tick:()=>interval?.(),engine,location};}

